require('nvim_comment').setup({
    comment_empty = false
})
